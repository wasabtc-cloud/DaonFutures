# 다온이 선물매매 v2.0

실시간 Binance Futures 공개 시세를 이용해 BTCUSDT/ETHUSDT의 4H·1H 추세와 15M 눌림 조건을 확인하고 LONG/SHORT 신호, 진입·SL·TP·RSI를 표시하는 Android 앱입니다.

## v2.0 변경점
- BTCUSDT / ETHUSDT
- 손절 0.5~3.0% / 익절 0.5~5.0% 조정
- 1배/2배/3배 레버리지 표시
- 푸시 알림 ON/OFF
- 15분 주기 백그라운드 분석
- 같은 15분 캔들의 같은 방향 신호 중복 알림 방지
- 최근 신호 20개 저장
- 홈 화면 Glance 위젯
- 위젯 터치 시 앱 열기
- 설정값을 백그라운드 작업과 공유

## 설치
### PC가 있는 경우
1. Android Studio 설치
2. 이 폴더를 Open
3. Gradle Sync
4. Android 13 이상은 알림 권한 허용
5. Run으로 휴대폰 또는 Emulator에 설치

Google 공식 Android Studio 설치 문서: https://developer.android.com/studio/install

### PC가 없는 경우
이 ZIP은 '소스 프로젝트'라서 ZIP 자체를 휴대폰에 바로 설치할 수는 없습니다. APK가 있어야 휴대폰만으로 설치할 수 있습니다.
이 프로젝트에는 GitHub Actions 자동 APK 빌드 설정이 포함되어 있어, GitHub에 프로젝트를 올려 Actions에서 APK를 만들 수 있습니다. 또한 Android Studio on IDX 같은 클라우드 개발환경을 사용할 수 있습니다.

## 위젯
홈 화면 빈 곳 길게 누르기 → 위젯 → 다온이 선물매매 → 홈 화면에 추가
위젯은 마지막 분석 결과를 보여주며, 터치하면 앱이 열립니다.

## 주의
- 실제 주문을 자동으로 넣지 않습니다.
- Binance API Key/Secret을 사용하지 않습니다.
- Android 전원관리 때문에 백그라운드 작업이 정확히 15분마다 실행된다고 보장할 수 없습니다.
- 투자 판단 및 실제 주문은 반드시 사용자가 직접 확인해야 합니다.
